export function getAdminToken(): string {
  if (typeof window === "undefined") {
    return "";
  }
  return sessionStorage.getItem("adminToken") || "";
}

export function getAdminHeaders(includeJsonContentType: boolean = true): Record<string, string> {
  const token = getAdminToken();
  const headers: Record<string, string> = {};

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  if (includeJsonContentType) {
    headers["Content-Type"] = "application/json";
  }

  return headers;
}

export function clearAdminSession(): void {
  if (typeof window === "undefined") {
    return;
  }
  sessionStorage.removeItem("adminToken");
  sessionStorage.removeItem("adminUsername");
}

