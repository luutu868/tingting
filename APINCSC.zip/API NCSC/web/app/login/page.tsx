"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { clearAdminSession } from "../../lib/adminAuth";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const login = async () => {
    setMessage("Authenticating...");
    const res = await fetch("/api/admin/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ username, password })
    });

    if (!res.ok) {
      clearAdminSession();
      setMessage("Invalid username or password");
      return;
    }

    const body = await res.json();
    sessionStorage.setItem("adminToken", body.access_token);
    sessionStorage.setItem("adminUsername", body.username || username);
    router.push("/admin");
  };

  return (
    <div className="center-page">
      <div className="card login-card">
        <div className="hero">
          <h1 style={{ margin: "0 0 8px" }}>Admin Login</h1>
          <p style={{ margin: 0 }}>Sign in to manage sensors, logs and rotation policy.</p>
        </div>
        <div className="row" style={{ display: "grid", gap: 10 }}>
          <input
            placeholder="Username"
            className="input-control"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            placeholder="Password"
            type="password"
            className="input-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button className="btn btn-primary" onClick={login}>Login</button>
          <div className="small" style={{ minHeight: 18 }}>{message}</div>
        </div>
      </div>
    </div>
  );
}

