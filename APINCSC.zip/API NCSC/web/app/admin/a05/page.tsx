"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import NoticeDialog from "../../../components/NoticeDialog";
import { getAdminHeaders, getAdminToken } from "../../../lib/adminAuth";

type A05Config = {
  enabled: boolean;
  endpoint_url: string;
  vendor_id: string;
  unit_id: string;
  sensor_id: string;
  timeout_seconds: number;
  verify_ssl: boolean;
  has_api_key: boolean;
};

export default function A05Page() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [config, setConfig] = useState<A05Config>({
    enabled: false,
    endpoint_url: "https://api.soc.gov.vn/api/v1/alerts",
    vendor_id: "VNPT_IT_01",
    unit_id: "0102595740",
    sensor_id: "01521ff3f10c721bce422d23",
    timeout_seconds: 10,
    verify_ssl: false,
    has_api_key: false,
  });
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [noticeState, setNoticeState] = useState({
    open: false,
    title: "",
    message: "",
  });

  const getHeaders = () => getAdminHeaders(true);

  const loadConfig = async () => {
    if (!getAdminToken()) {
      router.push("/login");
      return;
    }

    const res = await fetch("/api/admin/a05/config", { headers: getHeaders() });
    if (res.status === 401) {
      router.push("/login");
      return;
    }
    if (res.ok) {
      const data = (await res.json()) as A05Config;
      setConfig(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadConfig();
  }, []);

  const saveConfig = async () => {
    const payload = {
      ...config,
      api_key: apiKeyInput || undefined,
    };

    const res = await fetch("/api/admin/a05/config", {
      method: "PUT",
      headers: getHeaders(),
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      setNoticeState({ open: true, title: "Thành công", message: "Đã cập nhật cấu hình A05." });
      setApiKeyInput("");
      loadConfig();
      return;
    }

    const body = await res.json();
    setNoticeState({
      open: true,
      title: "Lỗi",
      message: body.detail || "Không thể lưu cấu hình A05.",
    });
  };

  const testConfig = async () => {
    const res = await fetch("/api/admin/a05/test", {
      method: "POST",
      headers: getHeaders(),
    });

    if (res.ok) {
      const body = await res.json();
      setNoticeState({
        open: true,
        title: "Kết nối thành công",
        message: `Status: ${body.status_code}. Response: ${body.response_text || "(empty)"}`,
      });
      return;
    }

    const body = await res.json();
    setNoticeState({
      open: true,
      title: "Kết nối thất bại",
      message: body.detail || "Không thể đẩy test data sang A05/BCA.",
    });
  };

  if (loading) {
    return <div className="panel">Đang tải cấu hình A05...</div>;
  }

  return (
    <div>
      <h1 className="page-title">Quản lý kết nối A05</h1>

      <div className="panel">
        <h2 className="section-title">Cấu hình đẩy data sang BCA</h2>
        <div className="form-row">
          <div className="field-group">
            <label>Endpoint URL</label>
            <input
              type="text"
              className="input-control"
              value={config.endpoint_url}
              onChange={(e) => setConfig((prev) => ({ ...prev, endpoint_url: e.target.value }))}
            />
          </div>
          <div className="field-group">
            <label>API Key (Basic)</label>
            <input
              type="password"
              className="input-control"
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder={config.has_api_key ? "Đã có key, nhập nếu muốn thay đổi" : "Nhập API key"}
            />
          </div>
        </div>

        <div className="form-row">
          <div className="field-group">
            <label>vendor_id (bắt buộc)</label>
            <input
              type="text"
              className="input-control"
              value={config.vendor_id}
              onChange={(e) => setConfig((prev) => ({ ...prev, vendor_id: e.target.value }))}
            />
          </div>
          <div className="field-group">
            <label>unit_id (bắt buộc)</label>
            <input
              type="text"
              className="input-control"
              value={config.unit_id}
              onChange={(e) => setConfig((prev) => ({ ...prev, unit_id: e.target.value }))}
            />
          </div>
          <div className="field-group">
            <label>sensor_id gửi sang BCA (bắt buộc)</label>
            <input
              type="text"
              className="input-control"
              value={config.sensor_id}
              onChange={(e) => setConfig((prev) => ({ ...prev, sensor_id: e.target.value }))}
            />
          </div>
        </div>

        <div className="form-row">
          <div className="field-group">
            <label>Timeout (giây)</label>
            <input
              type="number"
              className="input-control"
              min={1}
              max={60}
              value={config.timeout_seconds}
              onChange={(e) => setConfig((prev) => ({ ...prev, timeout_seconds: Number(e.target.value || 10) }))}
            />
          </div>
          <label className="inline-check">
            <input
              type="checkbox"
              checked={config.verify_ssl}
              onChange={(e) => setConfig((prev) => ({ ...prev, verify_ssl: e.target.checked }))}
            />
            Bật verify SSL
          </label>
          <label className="inline-check">
            <input
              type="checkbox"
              checked={config.enabled}
              onChange={(e) => setConfig((prev) => ({ ...prev, enabled: e.target.checked }))}
            />
            Bật đẩy dữ liệu A05
          </label>
        </div>

        <div className="form-row form-row-top-md">
          <button className="btn btn-primary" onClick={saveConfig}>Lưu cấu hình A05</button>
          <button className="btn btn-secondary" onClick={testConfig}>Test kết nối A05</button>
        </div>
      </div>

      <div className="note-box">
        <h3 className="section-title">Cơ chế gửi data</h3>
        <p>
          Khi bật cấu hình A05, mỗi event nhận qua API ingest sẽ được đẩy thêm sang BCA bằng HTTP PUT với header
          Authorization dạng Basic. Dữ liệu gửi đi sẽ tự động gắn thêm vendor_id, unit_id, sensor_id theo cấu hình tại trang này.
        </p>
      </div>

      <NoticeDialog
        open={noticeState.open}
        title={noticeState.title}
        message={noticeState.message}
        onClose={() => setNoticeState((prev) => ({ ...prev, open: false }))}
      />
    </div>
  );
}

