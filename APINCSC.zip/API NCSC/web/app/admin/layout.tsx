import Sidebar from '../../components/Sidebar';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="admin-shell">
      <Sidebar />
      <main className="main-pane">
        <div className="content-wrap">
          {children}
        </div>
      </main>
    </div>
  );
}
