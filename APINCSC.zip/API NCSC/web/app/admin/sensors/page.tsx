"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import ConfirmDialog from '../../../components/ConfirmDialog';
import NoticeDialog from '../../../components/NoticeDialog';
import { getAdminHeaders, getAdminToken } from '../../../lib/adminAuth';

type ConfirmState = {
  open: boolean;
  title: string;
  message: string;
  confirmText?: string;
  danger?: boolean;
  onConfirm: () => void | Promise<void>;
};

type NoticeState = {
  open: boolean;
  title: string;
  message: string;
  details?: string;
  copyValue?: string;
};

export default function SensorsPage() {
  const router = useRouter();
  const [sensors, setSensors] = useState<any[]>([]);
  const [newSensor, setNewSensor] = useState("");
  const [confirmState, setConfirmState] = useState<ConfirmState>({
    open: false,
    title: "",
    message: "",
    onConfirm: () => {},
  });
  const [noticeState, setNoticeState] = useState<NoticeState>({
    open: false,
    title: "",
    message: "",
  });

  const getHeaders = () => getAdminHeaders(true);

  const loadSensors = async () => {
    if (!getAdminToken()) {
      router.push('/login');
      return;
    }
    const res = await fetch('/api/admin/sensors', { headers: getHeaders() });
    if (res.status === 401) return router.push('/login');
    if (res.ok) setSensors(await res.json());
  };

  useEffect(() => { loadSensors(); }, []);

  const createSensor = async () => {
    if (!newSensor) return;
    const res = await fetch('/api/admin/sensors', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ sensor: newSensor })
    });
    if (res.ok) {
      const body = await res.json();
      setNoticeState({
        open: true,
        title: "Tạo sensor thành công",
        message: "Thông tin cấp phát sensor vừa tạo:",
        details: `Sensor ID: ${body.sensor_id}\nAPI Key: ${body.api_key}`,
        copyValue: body.api_key,
      });
      setNewSensor("");
      loadSensors();
    }
  };

  const deleteSensor = async (id: string) => {
    setConfirmState({
      open: true,
      title: "Xóa Sensor",
      message: "Bạn chắc chắn muốn xóa sensor này? Hành động này không thể hoàn tác.",
      confirmText: "Xóa",
      danger: true,
      onConfirm: async () => {
        await fetch(`/api/admin/sensors/${id}`, { method: 'DELETE', headers: getHeaders() });
        setConfirmState((prev) => ({ ...prev, open: false }));
        loadSensors();
      },
    });
  };

  const toggleSensor = async (id: string, sensor: string, currentStatus: boolean) => {
    await fetch(`/api/admin/sensors/${id}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify({ sensor, active: !currentStatus })
    });
    loadSensors();
  };

  const rotateKey = async (id: string) => {
    setConfirmState({
      open: true,
      title: "Cấp lại API Key",
      message: "Bạn muốn thu hồi API key cũ và cấp phát API key mới cho sensor này?",
      confirmText: "Cấp lại",
      danger: false,
      onConfirm: async () => {
        const res = await fetch(`/api/admin/sensors/${id}`, {
          method: 'PUT', headers: getHeaders(), body: JSON.stringify({ rotate_api_key: true })
        });
        if (res.ok) {
          const data = await res.json();
          setNoticeState({
            open: true,
            title: "Cấp lại API key thành công",
            message: "API key mới đã được cấp phát:",
            details: `${data.api_key}`,
            copyValue: data.api_key,
          });
        }
        setConfirmState((prev) => ({ ...prev, open: false }));
      },
    });
  };

  return (
    <div>
      <h1 className="page-title">Quản lý Sensors</h1>
      <div className="panel">
        <h2 className="section-title">Thêm Sensor Mới</h2>
        <div className="form-row">
          <input 
            type="text" 
            className="input-control" 
            placeholder="Tên Sensor" 
            value={newSensor} 
            onChange={(e) => setNewSensor(e.target.value)} 
          />
          <button className="btn btn-primary" onClick={createSensor}>Thêm</button>
        </div>
      </div>

      <div className="panel table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Sensor ID</th>
              <th>Tên Sensor</th>
              <th>Trạng Thái</th>
              <th>Actions (API Keys and Xóa)</th>
            </tr>
          </thead>
          <tbody>
            {sensors.map((s) => (
              <tr key={s.sensor_id}>
                <td className="mono">{s.sensor_id}</td>
                <td>{s.sensor || 'N/A'}</td>
                <td>
                  <button 
                    onClick={() => toggleSensor(s.sensor_id, s.sensor, s.active)}
                    className={`chip ${s.active ? 'chip-active' : 'chip-inactive'}`}
                  >
                    {s.active ? 'Active' : 'Disabled'}
                  </button>
                </td>
                <td>
                  <div className="inline-actions">
                    <button className="btn btn-warn" onClick={() => rotateKey(s.sensor_id)}>Cấp lại API Key</button>
                    <button className="btn btn-danger" onClick={() => deleteSensor(s.sensor_id)}>Xóa</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ConfirmDialog
        open={confirmState.open}
        title={confirmState.title}
        message={confirmState.message}
        confirmText={confirmState.confirmText}
        danger={confirmState.danger}
        onCancel={() => setConfirmState((prev) => ({ ...prev, open: false }))}
        onConfirm={confirmState.onConfirm}
      />

      <NoticeDialog
        open={noticeState.open}
        title={noticeState.title}
        message={noticeState.message}
        details={noticeState.details}
        copyValue={noticeState.copyValue}
        onClose={() => setNoticeState((prev) => ({ ...prev, open: false }))}
      />
    </div>
  );
}
