"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getAdminHeaders, getAdminToken } from "../../lib/adminAuth";

type SensorCount = {
  sensor_id: string;
  event_count: number;
  last_log_timestamp?: number;
  last_log_time?: string | null;
};

type DailyPoint = {
  date: string;
  timestamp: number;
  total: number;
  sensor_counts: Record<string, number>;
};

type MonthlyStats = {
  days: number;
  total_events: number;
  per_sensor: SensorCount[];
  daily_series: DailyPoint[];
};

const LINE_COLORS = ["#0f766e", "#2563eb", "#d97706", "#dc2626", "#7c3aed", "#0891b2"];

export default function Dashboard() {
  const router = useRouter();
  const [data, setData] = useState<MonthlyStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboard = async () => {
      const token = getAdminToken();
      if (!token) {
        router.push("/login");
        return;
      }
      
      const res = await fetch("/api/admin/stats/monthly?days=30", {
        headers: getAdminHeaders(false)
      });
      if (!res.ok) {
        if (res.status === 401) router.push("/login");
        setLoading(false);
        return;
      }
      
      const json = (await res.json()) as MonthlyStats;
      setData(json);
      setLoading(false);
    };
    fetchDashboard();
  }, [router]);

  const dailySeries = data?.daily_series || [];
  const topSensors = (data?.per_sensor || []).slice(0, 6).map((x) => x.sensor_id);
  const chartWidth = Math.max(900, dailySeries.length * 28);
  const chartHeight = 300;
  const padLeft = 48;
  const padBottom = 24;
  const padTop = 16;
  const innerWidth = chartWidth - padLeft - 16;
  const innerHeight = chartHeight - padTop - padBottom;
  const maxY = Math.max(
    1,
    ...topSensors.flatMap((sensorId) => dailySeries.map((d) => d.sensor_counts[sensorId] || 0))
  );

  const xAt = (idx: number) => {
    if (dailySeries.length <= 1) {
      return padLeft;
    }
    return padLeft + (idx / (dailySeries.length - 1)) * innerWidth;
  };

  const yAt = (value: number) => padTop + innerHeight - (value / maxY) * innerHeight;

  const buildPolyline = (sensorId: string) => {
    return dailySeries
      .map((point, idx) => `${xAt(idx)},${yAt(point.sensor_counts[sensorId] || 0)}`)
      .join(" ");
  };

  return (
    <div>
      <h1 className="page-title">Dashboard Thống Kê</h1>
      {loading ? (
        <div className="panel">Đang tải...</div>
      ) : (
        <>
          <div className="kpi-grid">
            <div className="panel">
              <h2 className="section-title">Tổng Event 30 ngày</h2>
              <p className="kpi-value">{data?.total_events || 0}</p>
            </div>
            <div className="panel">
              <h2 className="section-title">Số Sensor Có Dữ Liệu</h2>
              <p className="kpi-value">{data?.per_sensor?.length || 0}</p>
            </div>
          </div>

          <div className="panel">
            <h2 className="section-title">Thống kê bản ghi theo từng Sensor</h2>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Sensor ID</th>
                    <th>Số bản ghi ES (30 ngày)</th>
                    <th>Thời gian log gần nhất</th>
                  </tr>
                </thead>
                <tbody>
                  {(data?.per_sensor || []).map((row) => (
                    <tr key={row.sensor_id}>
                      <td className="mono">{row.sensor_id}</td>
                      <td>{row.event_count}</td>
                      <td>{row.last_log_time || "Chưa có"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="panel">
            <h2 className="section-title">Biểu đồ đường 1 tháng theo từng Sensor (user)</h2>
            <div className="legend-row">
              {topSensors.map((sensorId, index) => (
                <div className="legend-item" key={sensorId}>
                  <span className="legend-color" style={{ backgroundColor: LINE_COLORS[index % LINE_COLORS.length] }} />
                  <span className="mono">{sensorId}</span>
                </div>
              ))}
            </div>
            <div className="chart-wrap">
              <svg width={chartWidth} height={chartHeight} role="img" aria-label="Event by sensor in 30 days">
                <line x1={padLeft} y1={padTop} x2={padLeft} y2={chartHeight - padBottom} stroke="#94a3b8" />
                <line x1={padLeft} y1={chartHeight - padBottom} x2={chartWidth - 16} y2={chartHeight - padBottom} stroke="#94a3b8" />

                {topSensors.map((sensorId, index) => (
                  <polyline
                    key={sensorId}
                    fill="none"
                    stroke={LINE_COLORS[index % LINE_COLORS.length]}
                    strokeWidth="2"
                    points={buildPolyline(sensorId)}
                  />
                ))}

                {dailySeries.length > 0 ? (
                  <text x={padLeft} y={chartHeight - 6} fontSize="11" fill="#64748b">
                    {dailySeries[0].date}
                  </text>
                ) : null}
                {dailySeries.length > 0 ? (
                  <text x={chartWidth - 110} y={chartHeight - 6} fontSize="11" fill="#64748b">
                    {dailySeries[dailySeries.length - 1].date}
                  </text>
                ) : null}
              </svg>
            </div>
            <p className="muted">Ghi chú: "user" trong biểu đồ được hiểu là sensor_id đang đẩy dữ liệu.</p>
          </div>
        </>
      )}
    </div>
  );
}

