"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import NoticeDialog from '../../../components/NoticeDialog';
import ConfirmDialog from '../../../components/ConfirmDialog';
import { getAdminHeaders, getAdminToken } from '../../../lib/adminAuth';

type StorageConnection = {
  id: number;
  name: string;
  es_url: string;
  es_username?: string;
  has_password: boolean;
  is_active: boolean;
};

type ConnectionForm = {
  name: string;
  es_url: string;
  es_username: string;
  es_password: string;
  is_active: boolean;
};

export default function StoragePage() {
  const router = useRouter();
  const [rotation, setRotation] = useState({ rollover_max_age: '', delete_min_age: '' });
  const [connections, setConnections] = useState<StorageConnection[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<ConnectionForm>({
    name: '',
    es_url: '',
    es_username: '',
    es_password: '',
    is_active: false,
  });
  const [confirmState, setConfirmState] = useState({
    open: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });
  const [noticeState, setNoticeState] = useState({
    open: false,
    title: '',
    message: '',
  });

  const getHeaders = () => getAdminHeaders(true);

  const loadRotation = async () => {
    if (!getAdminToken()) {
      router.push('/login');
      return;
    }
    const res = await fetch('/api/admin/log-rotation', { headers: getHeaders() });
    if (res.status === 401) return router.push('/login');
    if (res.ok) setRotation(await res.json());
  };

  const loadConnections = async () => {
    const res = await fetch('/api/admin/storage/connections', { headers: getHeaders() });
    if (res.status === 401) return router.push('/login');
    if (res.ok) {
      const rows = (await res.json()) as StorageConnection[];
      setConnections(rows);
    }
  };

  useEffect(() => {
    loadRotation();
    loadConnections();
  }, []);

  const saveRotation = async () => {
    const res = await fetch('/api/admin/log-rotation', {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify({ 
        rollover_max_age: rotation.rollover_max_age, 
        delete_min_age: rotation.delete_min_age 
      })
    });
    if (res.ok) {
      setNoticeState({
        open: true,
        title: 'Thành công',
        message: 'Cập nhật rotation thành công.',
      });
      loadRotation();
    } else {
      const b = await res.json();
      setNoticeState({
        open: true,
        title: 'Thất bại',
        message: b.detail || 'Cập nhật thất bại',
      });
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setForm({
      name: '',
      es_url: '',
      es_username: '',
      es_password: '',
      is_active: false,
    });
  };

  const saveConnection = async () => {
    if (!form.name.trim() || !form.es_url.trim()) {
      setNoticeState({ open: true, title: 'Thiếu dữ liệu', message: 'Tên kết nối và ES URL là bắt buộc.' });
      return;
    }

    const payload = {
      name: form.name,
      es_url: form.es_url,
      es_username: form.es_username,
      es_password: form.es_password,
      is_active: form.is_active,
    };

    const res = await fetch(
      editingId == null ? '/api/admin/storage/connections' : `/api/admin/storage/connections/${editingId}`,
      {
        method: editingId == null ? 'POST' : 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(payload),
      }
    );

    if (res.ok) {
      setNoticeState({
        open: true,
        title: 'Thành công',
        message: editingId == null ? 'Đã tạo kết nối ES.' : 'Đã cập nhật kết nối ES.',
      });
      resetForm();
      loadConnections();
      return;
    }

    const body = await res.json();
    setNoticeState({
      open: true,
      title: 'Lỗi',
      message: body.detail || 'Không thể lưu kết nối ES.',
    });
  };

  const startEdit = (row: StorageConnection) => {
    setEditingId(row.id);
    setForm({
      name: row.name,
      es_url: row.es_url,
      es_username: row.es_username || '',
      es_password: '',
      is_active: row.is_active,
    });
  };

  const testConnection = async (connectionId: number) => {
    const res = await fetch(`/api/admin/storage/connections/${connectionId}/test`, {
      method: 'POST',
      headers: getHeaders(),
    });

    if (res.ok) {
      const body = await res.json();
      setNoticeState({
        open: true,
        title: 'Kết nối thành công',
        message: `Cluster: ${body.cluster_name || 'N/A'} | Version: ${body.version || 'N/A'}`,
      });
      return;
    }

    const body = await res.json();
    setNoticeState({
      open: true,
      title: 'Kết nối thất bại',
      message: body.detail || 'Không thể kết nối tới Elasticsearch.',
    });
  };

  const deleteConnection = (connectionId: number, name: string) => {
    setConfirmState({
      open: true,
      title: 'Xóa kết nối ES',
      message: `Bạn có chắc muốn xóa kết nối "${name}"?`,
      onConfirm: async () => {
        const res = await fetch(`/api/admin/storage/connections/${connectionId}`, {
          method: 'DELETE',
          headers: getHeaders(),
        });

        if (res.ok) {
          loadConnections();
        } else {
          setNoticeState({
            open: true,
            title: 'Xóa thất bại',
            message: 'Không thể xóa kết nối ES.',
          });
        }
        setConfirmState((prev) => ({ ...prev, open: false }));
      },
    });
  };

  return (
    <div>
      <h1 className="page-title">Quản lý Storage (Elasticsearch)</h1>

      <div className="panel">
        <h2 className="section-title">Cấu hình kết nối Elasticsearch bên thứ 3</h2>
        <div className="form-row">
          <div className="field-group">
            <label>Tên kết nối</label>
            <input
              type="text"
              className="input-control"
              value={form.name}
              onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))}
              placeholder="vd: ES Khách hàng A"
            />
          </div>
          <div className="field-group">
            <label>ES URL</label>
            <input
              type="text"
              className="input-control"
              value={form.es_url}
              onChange={(e) => setForm((prev) => ({ ...prev, es_url: e.target.value }))}
              placeholder="http://10.10.10.10:9200"
            />
          </div>
        </div>

        <div className="form-row">
          <div className="field-group">
            <label>Username (optional)</label>
            <input
              type="text"
              className="input-control"
              value={form.es_username}
              onChange={(e) => setForm((prev) => ({ ...prev, es_username: e.target.value }))}
              placeholder="elastic"
            />
          </div>
          <div className="field-group">
            <label>Password (để trống nếu không đổi)</label>
            <input
              type="password"
              className="input-control"
              value={form.es_password}
              onChange={(e) => setForm((prev) => ({ ...prev, es_password: e.target.value }))}
              placeholder="********"
            />
          </div>
        </div>

        <div className="form-row form-row-top-sm">
          <label className="inline-check">
            <input
              type="checkbox"
              title="Đặt làm kết nối active"
              checked={form.is_active}
              onChange={(e) => setForm((prev) => ({ ...prev, is_active: e.target.checked }))}
            />
            Đặt làm kết nối active
          </label>
        </div>

        <div className="form-row form-row-top-md">
          <button className="btn btn-primary" onClick={saveConnection}>
            {editingId == null ? 'Thêm kết nối' : 'Cập nhật kết nối'}
          </button>
          {editingId != null ? (
            <button className="btn btn-ghost" onClick={resetForm}>Hủy sửa</button>
          ) : null}
        </div>
      </div>

      <div className="panel table-wrap">
        <h2 className="section-title">Danh sách kết nối ES bên thứ 3</h2>
        <table className="data-table">
          <thead>
            <tr>
              <th>Tên</th>
              <th>URL</th>
              <th>Username</th>
              <th>Password</th>
              <th>Active</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {connections.length === 0 ? (
              <tr>
                <td colSpan={6} className="muted">Chưa có kết nối nào.</td>
              </tr>
            ) : (
              connections.map((row) => (
                <tr key={row.id}>
                  <td>{row.name}</td>
                  <td className="mono">{row.es_url}</td>
                  <td>{row.es_username || '-'}</td>
                  <td>{row.has_password ? 'Đã cấu hình' : '-'}</td>
                  <td>{row.is_active ? 'Yes' : 'No'}</td>
                  <td>
                    <div className="inline-actions">
                      <button className="btn btn-secondary" onClick={() => testConnection(row.id)}>Test</button>
                      <button className="btn btn-warn" onClick={() => startEdit(row)}>Sửa</button>
                      <button className="btn btn-danger" onClick={() => deleteConnection(row.id, row.name)}>Xóa</button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="panel">
        <h2 className="section-title">Cấu Hình Log Rotation (ILM)</h2>
        <div className="form-row">
          <div className="field-group">
            <label>Rollover Max Age (vd: 1d, 12h)</label>
            <input 
              type="text" 
              className="input-control" 
              value={rotation.rollover_max_age} 
              onChange={(e) => setRotation({...rotation, rollover_max_age: e.target.value})} 
            />
          </div>
          <div className="field-group">
            <label>Delete Min Age (vd: 30d, 4w)</label>
            <input 
              type="text" 
              className="input-control" 
              value={rotation.delete_min_age} 
              onChange={(e) => setRotation({...rotation, delete_min_age: e.target.value})} 
            />
          </div>
        </div>
        <button 
          className="btn btn-primary" 
          onClick={saveRotation}
        >
          Lưu Rotation Config
        </button>
      </div>

      <div className="note-box">
        <h3 className="section-title">Lưu ý kết nối hệ thống ES Khác:</h3>
        <p>
          Hiện tại kết nối ES được thiết lập tĩnh qua biến môi trường (<code>ES_URL</code>, <code>ES_USERNAME</code>, <code>ES_PASSWORD</code>). 
          Nếu cần cấu hình động liên kết sang các cụm ELK (Elasticsearch/Logstash/Kibana) khác, 
          quy trình cần thay đổi architecture để lưu trữ các endpoint ES trong Database PostgreSQL, và 
          routing tuỳ thuộc vào sensor/organization nào được cấp phát cho ES cluster tương ứng.
        </p>
      </div>

      <NoticeDialog
        open={noticeState.open}
        title={noticeState.title}
        message={noticeState.message}
        onClose={() => setNoticeState((prev) => ({ ...prev, open: false }))}
      />

      <ConfirmDialog
        open={confirmState.open}
        title={confirmState.title}
        message={confirmState.message}
        confirmText="Xóa"
        danger={true}
        onCancel={() => setConfirmState((prev) => ({ ...prev, open: false }))}
        onConfirm={confirmState.onConfirm}
      />
    </div>
  );
}
