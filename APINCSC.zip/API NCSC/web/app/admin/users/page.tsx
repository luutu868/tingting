"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import ConfirmDialog from '../../../components/ConfirmDialog';
import NoticeDialog from '../../../components/NoticeDialog';
import { clearAdminSession, getAdminHeaders, getAdminToken } from '../../../lib/adminAuth';

type ConfirmState = {
  open: boolean;
  title: string;
  message: string;
  confirmText?: string;
  danger?: boolean;
  onConfirm: () => void | Promise<void>;
};

type NoticeState = {
  open: boolean;
  title: string;
  message: string;
  details?: string;
};

type PasswordModalState = {
  open: boolean;
  username: string;
  currentPassword: string;
  newPassword: string;
  confirmNewPassword: string;
};

export default function UsersPage() {
  const router = useRouter();
  const [users, setUsers] = useState<any[]>([]);
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmState, setConfirmState] = useState<ConfirmState>({
    open: false,
    title: "",
    message: "",
    onConfirm: () => {},
  });
  const [noticeState, setNoticeState] = useState<NoticeState>({
    open: false,
    title: "",
    message: "",
  });
  const [passwordModal, setPasswordModal] = useState<PasswordModalState>({
    open: false,
    username: "",
    currentPassword: "",
    newPassword: "",
    confirmNewPassword: "",
  });

  const getHeaders = () => getAdminHeaders(true);

  const loadUsers = async () => {
    if (!getAdminToken()) {
      router.push('/login');
      return;
    }
    const res = await fetch('/api/admin/users', { headers: getHeaders() });
    if (res.status === 401) return router.push('/login');
    if (res.ok) setUsers(await res.json());
  };

  useEffect(() => { loadUsers(); }, []);

  const createUser = async () => {
    if (!newUsername || !newPassword) {
      setNoticeState({
        open: true,
        title: "Thiếu dữ liệu",
        message: "Cần nhập đầy đủ username và password.",
      });
      return;
    }

    const res = await fetch('/api/admin/users', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ username: newUsername, password: newPassword })
    });
    if (res.ok) {
      setNoticeState({
        open: true,
        title: "Thành công",
        message: "Tạo tài khoản quản trị thành công.",
      });
      setNewUsername("");
      setNewPassword("");
      loadUsers();
    } else {
      const data = await res.json();
      setNoticeState({
        open: true,
        title: "Tạo user thất bại",
        message: data.detail || 'Không thể tạo user',
      });
    }
  };

  const deleteUser = async (username: string) => {
    setConfirmState({
      open: true,
      title: "Xóa Tài Khoản Admin",
      message: `Bạn chắc chắn muốn xóa quản trị viên ${username}?`,
      confirmText: "Xóa",
      danger: true,
      onConfirm: async () => {
        const res = await fetch(`/api/admin/users/${username}`, { method: 'DELETE', headers: getHeaders() });
        if (res.ok) {
          loadUsers();
        } else {
          setNoticeState({
            open: true,
            title: "Xóa user thất bại",
            message: 'Không thể xóa tài khoản này',
          });
        }
        setConfirmState((prev) => ({ ...prev, open: false }));
      },
    });
  };

  const openChangePassword = (username: string) => {
    setPasswordModal({
      open: true,
      username,
      currentPassword: "",
      newPassword: "",
      confirmNewPassword: "",
    });
  };

  const submitChangePassword = async () => {
    if (!passwordModal.currentPassword.trim() || !passwordModal.newPassword.trim()) {
      setNoticeState({
        open: true,
        title: "Thiếu dữ liệu",
        message: "Vui lòng nhập mật khẩu hiện tại và mật khẩu mới.",
      });
      return;
    }

    if (passwordModal.newPassword !== passwordModal.confirmNewPassword) {
      setNoticeState({
        open: true,
        title: "Xác nhận mật khẩu chưa đúng",
        message: "Mật khẩu mới và xác nhận mật khẩu phải trùng nhau.",
      });
      return;
    }

    const res = await fetch(`/api/admin/users/${passwordModal.username}/password`, {
      method: "PUT",
      headers: getHeaders(),
      body: JSON.stringify({
        current_password: passwordModal.currentPassword,
        new_password: passwordModal.newPassword,
      }),
    });

    if (res.ok) {
      const currentUsername = sessionStorage.getItem("adminUsername");
      if (currentUsername === passwordModal.username) {
        clearAdminSession();
        router.push('/login');
        return;
      }

      setPasswordModal((prev) => ({ ...prev, open: false }));
      setNoticeState({
        open: true,
        title: "Thành công",
        message: `Đổi mật khẩu cho ${passwordModal.username} thành công.`,
      });
      return;
    }

    const data = await res.json();
    setNoticeState({
      open: true,
      title: "Đổi mật khẩu thất bại",
      message: data.detail || "Không thể đổi mật khẩu.",
    });
  };

  return (
    <div>
      <h1 className="page-title">Quản lý Tài Khoản Admin</h1>
      
      <div className="panel">
        <h2 className="section-title">Thêm Admin Mới</h2>
        <div className="form-row">
          <input 
            type="text" 
            className="input-control" 
            placeholder="Username" 
            value={newUsername} 
            onChange={(e) => setNewUsername(e.target.value)} 
          />
          <input 
            type="password" 
            className="input-control" 
            placeholder="Password" 
            value={newPassword} 
            onChange={(e) => setNewPassword(e.target.value)} 
          />
          <button className="btn btn-primary" onClick={createUser}>Thêm Tài Khoản</button>
        </div>
        <p className="muted">Tính năng này yêu cầu backend hỗ trợ API POST /admin/users</p>
      </div>

      <div className="panel table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Username</th>
              <th>Thao Tác</th>
            </tr>
          </thead>
          <tbody>
            {users.length > 0 ? users.map((u) => (
              <tr key={u.username}>
                <td>{u.username}</td>
                <td>
                  <div className="inline-actions">
                    <button
                      className="btn btn-secondary"
                      onClick={() => openChangePassword(u.username)}
                    >
                      Đổi mật khẩu
                    </button>
                    <button 
                      className="btn btn-danger" 
                      onClick={() => deleteUser(u.username)}
                    >
                      Xóa
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr><td colSpan={2} className="muted">Chưa có dữ liệu users hoặc chưa hỗ trợ route</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {passwordModal.open ? (
        <div className="dialog-backdrop" role="dialog" aria-modal="true">
          <div className="dialog-card">
            <h3 className="dialog-title">Đổi mật khẩu user</h3>
            <p className="dialog-message">User: <span className="mono">{passwordModal.username}</span></p>
            <div style={{ marginTop: 10 }}>
              <input
                type="password"
                className="input-control"
                placeholder="Mật khẩu admin hiện tại"
                value={passwordModal.currentPassword}
                onChange={(e) =>
                  setPasswordModal((prev) => ({ ...prev, currentPassword: e.target.value }))
                }
              />
            </div>
            <div style={{ marginTop: 10 }}>
              <input
                type="password"
                className="input-control"
                placeholder="Nhập mật khẩu mới"
                value={passwordModal.newPassword}
                onChange={(e) =>
                  setPasswordModal((prev) => ({ ...prev, newPassword: e.target.value }))
                }
              />
            </div>
            <div style={{ marginTop: 10 }}>
              <input
                type="password"
                className="input-control"
                placeholder="Nhập lại mật khẩu mới"
                value={passwordModal.confirmNewPassword}
                onChange={(e) =>
                  setPasswordModal((prev) => ({ ...prev, confirmNewPassword: e.target.value }))
                }
              />
            </div>
            <div className="dialog-actions">
              <button
                className="btn btn-ghost"
                onClick={() => setPasswordModal((prev) => ({ ...prev, open: false }))}
              >
                Hủy
              </button>
              <button className="btn btn-primary" onClick={submitChangePassword}>
                Lưu mật khẩu
              </button>
            </div>
          </div>
        </div>
      ) : null}

      <ConfirmDialog
        open={confirmState.open}
        title={confirmState.title}
        message={confirmState.message}
        confirmText={confirmState.confirmText}
        danger={confirmState.danger}
        onCancel={() => setConfirmState((prev) => ({ ...prev, open: false }))}
        onConfirm={confirmState.onConfirm}
      />

      <NoticeDialog
        open={noticeState.open}
        title={noticeState.title}
        message={noticeState.message}
        details={noticeState.details}
        onClose={() => setNoticeState((prev) => ({ ...prev, open: false }))}
      />
    </div>
  );
}
