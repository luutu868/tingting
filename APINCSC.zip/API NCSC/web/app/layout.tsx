import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "NCSC Admin UI",
  description: "Admin UI for sensor and logs management"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

