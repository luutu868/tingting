"use client";
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { clearAdminSession } from '../lib/adminAuth';

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = () => {
    clearAdminSession();
    router.push('/login');
  };

  const links = [
    { href: '/admin', label: 'Dashboard' },
    { href: '/admin/sensors', label: 'Quản lý Sensors' },
    { href: '/admin/users', label: 'Quản lý Users' },
    { href: '/admin/storage', label: 'Quản lý Storage (ES)' },
    { href: '/admin/a05', label: 'Kết nối A05 (BCA)' },
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <h2 className="sidebar-title">NCSC Admin</h2>
        <p className="sidebar-subtitle">Sensor and ES Control</p>
      </div>
      <nav className="sidebar-nav">
        <ul>
          {links.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className={`sidebar-link ${
                  pathname === link.href ? 'active' : ''
                }`}
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <div className="sidebar-footer">
        <button
          onClick={handleLogout}
          className="btn btn-danger btn-block"
        >
          Đăng xuất
        </button>
      </div>
    </aside>
  );
}
