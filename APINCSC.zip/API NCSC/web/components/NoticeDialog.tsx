"use client";
import { useEffect, useState } from "react";

type NoticeDialogProps = {
  open: boolean;
  title: string;
  message: string;
  details?: string;
  copyValue?: string;
  closeText?: string;
  onClose: () => void;
};

export default function NoticeDialog({
  open,
  title,
  message,
  details,
  copyValue,
  closeText = "Đóng",
  onClose,
}: NoticeDialogProps) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open) {
      setCopied(false);
    }
  }, [open]);

  const onCopy = async () => {
    if (!copyValue) {
      return;
    }

    try {
      await navigator.clipboard.writeText(copyValue);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  if (!open) {
    return null;
  }

  return (
    <div className="dialog-backdrop" role="dialog" aria-modal="true">
      <div className="dialog-card">
        <h3 className="dialog-title">{title}</h3>
        <p className="dialog-message">{message}</p>
        {details ? <pre className="dialog-details mono">{details}</pre> : null}
        <div className="dialog-actions">
          {copyValue ? (
            <button className="btn btn-secondary" onClick={onCopy}>
              {copied ? "Đã copy" : "Copy API Key"}
            </button>
          ) : null}
          <button className="btn btn-primary" onClick={onClose}>
            {closeText}
          </button>
        </div>
      </div>
    </div>
  );
}

