import hashlib
import hmac
import secrets
import time
import base64
import json
import logging
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from elasticsearch import Elasticsearch, helpers
from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import BaseModel, model_validator
from sqlalchemy import Boolean, Integer, String, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker
import requests

import os


load_dotenv()


DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg://sensor_admin:sensor_password@localhost:5432/sensor_db")
DEFAULT_ADMIN_USERNAME = os.getenv("DEFAULT_ADMIN_USERNAME", "admin")
DEFAULT_ADMIN_PASSWORD = os.getenv("DEFAULT_ADMIN_PASSWORD", "change-me")
ES_URL = os.getenv("ES_URL", "http://localhost:9200")
ES_USERNAME = os.getenv("ES_USERNAME")
ES_PASSWORD = os.getenv("ES_PASSWORD")
ES_INDEX = os.getenv("ES_INDEX", "sensor-events")
ES_ROLLOVER_MAX_AGE = os.getenv("ES_ROLLOVER_MAX_AGE", "1d")
ES_DELETE_MIN_AGE = os.getenv("ES_DELETE_MIN_AGE", "30d")
ADMIN_TOKEN_SECRET = os.getenv("ADMIN_TOKEN_SECRET", "change-this-admin-token-secret")
ADMIN_TOKEN_EXPIRES_SECONDS = int(os.getenv("ADMIN_TOKEN_EXPIRES_SECONDS", "28800"))
ES_WRITE_ALIAS = f"{ES_INDEX}-write"
ES_BOOTSTRAP_INDEX = f"{ES_INDEX}-000001"
ES_ILM_POLICY_NAME = f"{ES_INDEX}-policy"
ES_INDEX_TEMPLATE_NAME = f"{ES_INDEX}-template"


logger = logging.getLogger("uvicorn.error")
logger.setLevel(logging.INFO)


def build_a05_authorization_header(api_key: str) -> str:
    raw = (api_key or "").strip()
    if not raw:
        raise ValueError("A05 api_key is empty")

    if raw.lower().startswith("basic "):
        token = raw[6:].strip()
        try:
            token.encode("ascii")
            return f"Basic {token}"
        except UnicodeEncodeError:
            encoded = base64.b64encode(token.encode("utf-8")).decode("ascii")
            return f"Basic {encoded}"

    try:
        raw.encode("ascii")
        return f"Basic {raw}"
    except UnicodeEncodeError:
        encoded = base64.b64encode(raw.encode("utf-8")).decode("ascii")
        return f"Basic {encoded}"


class Base(DeclarativeBase):
    pass


class Sensor(Base):
    __tablename__ = "sensors"

    sensor_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    sensor: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    api_key_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class AdminAccount(Base):
    __tablename__ = "admin_accounts"

    username: Mapped[str] = mapped_column(String(128), primary_key=True)
    password_hash: Mapped[str] = mapped_column(String(128), nullable=False)


class StorageConnection(Base):
    __tablename__ = "storage_connections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    es_url: Mapped[str] = mapped_column(String(512), nullable=False)
    es_username: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    es_password: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class A05Connection(Base):
    __tablename__ = "a05_connections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    endpoint_url: Mapped[str] = mapped_column(String(512), nullable=False)
    api_key: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    vendor_id: Mapped[str] = mapped_column(String(128), nullable=False)
    unit_id: Mapped[str] = mapped_column(String(128), nullable=False)
    sensor_id: Mapped[str] = mapped_column(String(128), nullable=False)
    timeout_seconds: Mapped[int] = mapped_column(Integer, default=10, nullable=False)
    verify_ssl: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


es_client: Optional[Elasticsearch] = None


@asynccontextmanager
async def lifespan(_: FastAPI):
    global es_client

    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        ensure_default_admin_account(db)
        ensure_default_a05_connection(db)

    if ES_USERNAME and ES_PASSWORD:
        es_client = Elasticsearch(ES_URL, basic_auth=(ES_USERNAME, ES_PASSWORD))
    else:
        es_client = Elasticsearch(ES_URL)

    try:
        ensure_index_management(es_client, ES_ROLLOVER_MAX_AGE, ES_DELETE_MIN_AGE)
    except Exception as ex:
        raise RuntimeError(f"Failed to initialize Elasticsearch ILM/index template: {str(ex)}")

    yield

    if es_client is not None:
        es_client.close()


app = FastAPI(title="Sensor Ingest API", version="1.0.0", lifespan=lifespan)


class GeoIPPayload(BaseModel):
    lat: float
    lon: float
    ip: str
    city_name: str
    countryname: str
    country_code: str
    timezone: str
    region_name: str


class EventPayload(BaseModel):
    timestamp: float
    category: int
    action: int
    signature: str
    severity: int
    direction: int
    dest_ip: str
    dest_port: int
    src_ip: str
    src_port: int
    proto: str
    host: str
    tags: int
    domain: Optional[str] = None
    geoip: Optional[GeoIPPayload] = None

    @model_validator(mode="after")
    def validate_geoip_requirement(self) -> "EventPayload":
        # tags=1 means this event must include a complete geoip object.
        if self.tags == 1 and self.geoip is None:
            raise ValueError("geoip is required when tags=1")
        return self


class IngestRequest(BaseModel):
    data: List[EventPayload]


class SensorCreateRequest(BaseModel):
    sensor: Optional[str] = None
    name: Optional[str] = None

    @model_validator(mode="after")
    def normalize_sensor_name(self) -> "SensorCreateRequest":
        if self.sensor is None and self.name is not None:
            self.sensor = self.name
        return self


class SensorUpdateRequest(BaseModel):
    sensor: Optional[str] = None
    name: Optional[str] = None
    active: Optional[bool] = None
    rotate_api_key: bool = False

    @model_validator(mode="after")
    def normalize_sensor_name(self) -> "SensorUpdateRequest":
        if self.sensor is None and self.name is not None:
            self.sensor = self.name
        return self


class SensorPublicResponse(BaseModel):
    sensor_id: str
    sensor: Optional[str]
    active: bool


class SensorCreateResponse(SensorPublicResponse):
    api_key: str


class AdminAccountUpdateRequest(BaseModel):
    current_password: str
    new_username: Optional[str] = None
    new_password: Optional[str] = None

    @model_validator(mode="after")
    def validate_change(self) -> "AdminAccountUpdateRequest":
        if not self.new_username and not self.new_password:
            raise ValueError("Provide new_username or new_password")
        return self


class AdminTokenRequest(BaseModel):
    username: str
    password: str


class A05ConfigUpdateRequest(BaseModel):
    enabled: bool
    endpoint_url: str
    api_key: Optional[str] = None
    vendor_id: str
    unit_id: str
    sensor_id: str
    timeout_seconds: int = 10
    verify_ssl: bool = False

    @model_validator(mode="after")
    def validate_fields(self) -> "A05ConfigUpdateRequest":
        if not self.endpoint_url.strip():
            raise ValueError("endpoint_url is required")
        if not (self.endpoint_url.startswith("http://") or self.endpoint_url.startswith("https://")):
            raise ValueError("endpoint_url must start with http:// or https://")
        if not self.vendor_id.strip() or not self.unit_id.strip() or not self.sensor_id.strip():
            raise ValueError("vendor_id, unit_id, sensor_id are required")
        if self.timeout_seconds < 1 or self.timeout_seconds > 60:
            raise ValueError("timeout_seconds must be in range 1..60")
        return self


class A05ConfigResponse(BaseModel):
    enabled: bool
    endpoint_url: str
    vendor_id: str
    unit_id: str
    sensor_id: str
    timeout_seconds: int
    verify_ssl: bool
    has_api_key: bool


class LogRotationConfig(BaseModel):
    rollover_max_age: str
    delete_min_age: str

    @model_validator(mode="after")
    def validate_age_fields(self) -> "LogRotationConfig":
        for val, field_name in [
            (self.rollover_max_age, "rollover_max_age"),
            (self.delete_min_age, "delete_min_age"),
        ]:
            if len(val) < 2 or not val[:-1].isdigit() or val[-1] not in {"s", "m", "h", "d", "w", "M", "y"}:
                raise ValueError(
                    f"{field_name} must follow Elasticsearch time unit format like 12h, 7d, 4w, 3M"
                )
        return self


def ensure_index_management(es: Elasticsearch, rollover_max_age: str, delete_min_age: str) -> None:
    policy_body = {
        "policy": {
            "phases": {
                "hot": {
                    "actions": {
                        "rollover": {
                            "max_age": rollover_max_age,
                        }
                    }
                },
                "delete": {
                    "min_age": delete_min_age,
                    "actions": {"delete": {}},
                },
            }
        }
    }
    es.ilm.put_lifecycle(name=ES_ILM_POLICY_NAME, policy=policy_body["policy"])

    template_body = {
        "index_patterns": [f"{ES_INDEX}-*"],
        "template": {
            "settings": {
                "index.lifecycle.name": ES_ILM_POLICY_NAME,
                "index.lifecycle.rollover_alias": ES_WRITE_ALIAS,
            }
        },
        "priority": 500,
    }
    es.indices.put_index_template(name=ES_INDEX_TEMPLATE_NAME, body=template_body)

    if not es.indices.exists(index=ES_BOOTSTRAP_INDEX):
        es.indices.create(
            index=ES_BOOTSTRAP_INDEX,
            aliases={
                ES_WRITE_ALIAS: {
                    "is_write_index": True,
                }
            },
        )


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def ensure_default_admin_account(db: Session) -> None:
    stmt = select(AdminAccount).limit(1)
    existing_admin = db.execute(stmt).scalar_one_or_none()
    if existing_admin is not None:
        return

    admin = AdminAccount(
        username=DEFAULT_ADMIN_USERNAME,
        password_hash=hash_secret(DEFAULT_ADMIN_PASSWORD),
    )
    db.add(admin)
    db.commit()


def ensure_default_a05_connection(db: Session) -> None:
    existing = db.execute(select(A05Connection).limit(1)).scalar_one_or_none()
    if existing is not None:
        return

    default_row = A05Connection(
        enabled=False,
        endpoint_url="https://api.soc.gov.vn/api/v1/alerts",
        api_key=None,
        vendor_id="VNPT_IT_01",
        unit_id="0102595740",
        sensor_id="01521ff3f10c721bce422d23",
        timeout_seconds=10,
        verify_ssl=False,
    )
    db.add(default_row)
    db.commit()


def hash_secret(raw_value: str) -> str:
    return hashlib.sha256(raw_value.encode("utf-8")).hexdigest()


def hash_api_key(raw_key: str) -> str:
    return hash_secret(raw_key)


def generate_sensor_id() -> str:
    return secrets.token_hex(12)


def generate_api_key() -> str:
    return secrets.token_urlsafe(32)


def authenticate_admin_credentials(db: Session, username: str, password: str) -> AdminAccount:
    admin = db.get(AdminAccount, username)
    if admin is None or admin.password_hash != hash_secret(password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin credentials",
        )
    return admin


def _b64url_encode(raw: str) -> str:
    return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("utf-8").rstrip("=")


def _b64url_decode(encoded: str) -> str:
    padding = "=" * (-len(encoded) % 4)
    return base64.urlsafe_b64decode((encoded + padding).encode("utf-8")).decode("utf-8")


def create_admin_token(admin: AdminAccount) -> str:
    expires_at = int(time.time()) + ADMIN_TOKEN_EXPIRES_SECONDS
    credential_stamp = hash_secret(admin.password_hash + ADMIN_TOKEN_SECRET)
    payload = f"{admin.username}:{expires_at}:{credential_stamp}"
    signature = hmac.new(
        ADMIN_TOKEN_SECRET.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return _b64url_encode(f"{payload}:{signature}")


def decode_and_validate_admin_token(token: str, db: Session) -> AdminAccount:
    try:
        decoded = _b64url_decode(token)
        username, expires_at_raw, credential_stamp, signature = decoded.split(":", 3)
        payload = f"{username}:{expires_at_raw}:{credential_stamp}"
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid bearer token")

    expected_signature = hmac.new(
        ADMIN_TOKEN_SECRET.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(signature, expected_signature):
        raise HTTPException(status_code=401, detail="Invalid bearer token")

    try:
        expires_at = int(expires_at_raw)
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid bearer token")

    if expires_at < int(time.time()):
        raise HTTPException(status_code=401, detail="Bearer token expired")

    admin = db.get(AdminAccount, username)
    if admin is None:
        raise HTTPException(status_code=401, detail="Invalid bearer token")

    expected_stamp = hash_secret(admin.password_hash + ADMIN_TOKEN_SECRET)
    if not hmac.compare_digest(credential_stamp, expected_stamp):
        raise HTTPException(status_code=401, detail="Bearer token is no longer valid")

    return admin


def require_admin(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(default=None),
) -> AdminAccount:
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Authorization header",
        )

    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization must be Bearer <token>",
        )

    return decode_and_validate_admin_token(token.strip(), db)


def verify_sensor_credentials(db: Session, sensor_id: str, api_key: str) -> Sensor:
    stmt = select(Sensor).where(Sensor.sensor_id == sensor_id)
    sensor = db.execute(stmt).scalar_one_or_none()

    if sensor is None or not sensor.active:
        raise HTTPException(status_code=401, detail="Invalid sensor credentials")

    if sensor.api_key_hash != hash_api_key(api_key):
        raise HTTPException(status_code=401, detail="Invalid sensor credentials")

    return sensor


def serialize_a05_config(row: A05Connection) -> A05ConfigResponse:
    return A05ConfigResponse(
        enabled=row.enabled,
        endpoint_url=row.endpoint_url,
        vendor_id=row.vendor_id,
        unit_id=row.unit_id,
        sensor_id=row.sensor_id,
        timeout_seconds=row.timeout_seconds,
        verify_ssl=row.verify_ssl,
        has_api_key=bool(row.api_key),
    )


def forward_event_to_a05(config: A05Connection, event: Dict[str, Any]) -> Dict[str, Any]:
    auth_header = build_a05_authorization_header(config.api_key or "")
    headers = {
        "content-type": "application/json",
        "Authorization": auth_header,
    }
    payload = dict(event)
    payload["vendor_id"] = config.vendor_id
    payload["unit_id"] = config.unit_id
    payload["sensor_id"] = config.sensor_id

    logger.info(
        "A05 PUT attempt endpoint=%s timeout=%s verify_ssl=%s",
        config.endpoint_url,
        config.timeout_seconds,
        config.verify_ssl,
    )

    response = requests.put(
        config.endpoint_url,
        data=json.dumps(payload),
        headers=headers,
        verify=config.verify_ssl,
        timeout=config.timeout_seconds,
    )
    result = {
        "endpoint_url": config.endpoint_url,
        "request_payload": payload,
        "status_code": response.status_code,
        "response_text": response.text.strip(),
        "ok": 200 <= response.status_code < 300,
    }
    logger.info("A05 PUT endpoint=%s status=%s", result["endpoint_url"], result["status_code"])
    logger.info(
        "A05 PUT payload=%s",
        json.dumps(result["request_payload"], ensure_ascii=False),
    )
    logger.info("A05 PUT response=%s", result["response_text"][:1000])
    return result


LOGIN_HTML = """
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Admin Login</title>
    <style>
        :root {
            --bg: #f5efe3;
            --card: #fffdf7;
            --ink: #1f2a44;
            --muted: #6b7280;
            --brand: #0f766e;
            --brand2: #b45309;
            --danger: #b91c1c;
            --line: #e7dcc8;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: var(--ink);
            background: radial-gradient(circle at 20% 0%, #f9d9a7 0%, var(--bg) 45%, #efe5d5 100%);
            min-height: 100vh;
            display: grid;
            place-items: center;
        }
        .card {
            width: min(480px, 92vw);
            background: var(--card);
            border: 1px solid var(--line);
            border-radius: 16px;
            padding: 18px;
            box-shadow: 0 10px 30px rgba(31,42,68,.12);
            animation: rise .35s ease;
        }
        .hero {
            background: linear-gradient(135deg, #0f766e, #0d9488 65%, #b45309);
            color: #fff;
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 14px;
        }
        .hero h1 { margin: 0 0 8px; font-size: 24px; }
        .hero p { margin: 0; opacity: .95; }
        @keyframes rise { from { transform: translateY(8px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .row { display: grid; gap: 8px; }
        input, button {
            height: 36px;
            border-radius: 10px;
            border: 1px solid var(--line);
            padding: 0 10px;
            font-size: 14px;
        }
        input { background: #fff; min-width: 160px; width: 100%; }
        button { background: var(--brand); color: #fff; border: none; cursor: pointer; }
        .small { color: var(--muted); font-size: 12px; }
        #msg { min-height: 18px; }
    </style>
</head>
<body>
    <div class="card">
        <div class="hero">
            <h1>Admin Login</h1>
            <p>Dang nhap vao he thong quan tri sensor/logs.</p>
        </div>
        <div class="row">
            <input id="adminUsername" placeholder="Username" />
            <input id="adminPassword" type="password" placeholder="Password" />
            <button onclick="login()">Dang nhap</button>
        </div>
        <div id="msg" class="small" style="margin-top:8px"></div>
    </div>

    <script>
        const adminUsernameEl = document.getElementById('adminUsername');
        const adminPasswordEl = document.getElementById('adminPassword');
        adminUsernameEl.value = sessionStorage.getItem('adminUsername') || '';
        adminPasswordEl.value = sessionStorage.getItem('adminPassword') || '';

        function adminHeaders() {
            const username = adminUsernameEl.value.trim();
            const password = adminPasswordEl.value;
            return {
                'Content-Type': 'application/json',
                'X-Admin-Username': username,
                'X-Admin-Password': password,
            };
        }

        async function login() {
            const msg = document.getElementById('msg');
            msg.textContent = 'Dang xac thuc...';
            const res = await fetch('/admin/account', { headers: adminHeaders() });
            if (!res.ok) {
                msg.textContent = 'Sai username/password';
                return;
            }
            sessionStorage.setItem('adminUsername', adminUsernameEl.value.trim());
            sessionStorage.setItem('adminPassword', adminPasswordEl.value);
            window.location.href = '/admin/ui/admin';
        }
    </script>
</body>
</html>
"""


ADMIN_DASHBOARD_HTML = """
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Admin Dashboard</title>
    <style>
        :root {
            --bg: #f5efe3;
            --card: #fffdf7;
            --ink: #1f2a44;
            --muted: #6b7280;
            --brand: #0f766e;
            --brand2: #b45309;
            --danger: #b91c1c;
            --line: #e7dcc8;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: var(--ink);
            background: radial-gradient(circle at 20% 0%, #f9d9a7 0%, var(--bg) 45%, #efe5d5 100%);
        }
        .wrap { max-width: 1200px; margin: 20px auto; padding: 0 14px; }
        .hero {
            background: linear-gradient(135deg, #0f766e, #0d9488 65%, #b45309);
            color: #fff;
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 16px;
            box-shadow: 0 10px 30px rgba(31,42,68,.18);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .hero h1 { margin: 0 0 8px; font-size: 24px; }
        .hero p { margin: 0; opacity: .95; }
        .grid { display: grid; gap: 14px; grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .card {
            background: var(--card);
            border: 1px solid var(--line);
            border-radius: 14px;
            padding: 14px;
            box-shadow: 0 10px 24px rgba(31,42,68,.06);
            animation: rise .35s ease;
        }
        @keyframes rise { from { transform: translateY(8px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .card h2 { margin: 0 0 10px; font-size: 18px; }
        .row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        input, button {
            height: 36px;
            border-radius: 10px;
            border: 1px solid var(--line);
            padding: 0 10px;
            font-size: 14px;
        }
        input { background: #fff; min-width: 160px; }
        button { background: var(--brand); color: #fff; border: none; cursor: pointer; }
        button.alt { background: var(--brand2); }
        button.danger { background: var(--danger); }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
        th, td { border-bottom: 1px solid var(--line); padding: 8px; text-align: left; vertical-align: top; }
        th { color: var(--muted); font-weight: 600; }
        .small { color: var(--muted); font-size: 12px; }
        .mono { font-family: Consolas, Menlo, monospace; font-size: 12px; }
        .full { grid-column: 1 / -1; }
        pre {
            max-height: 260px;
            overflow: auto;
            margin: 0;
            padding: 10px;
            background: #11203b;
            color: #d9e8ff;
            border-radius: 10px;
        }
        @media (max-width: 900px) { .grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="wrap">
        <div class="hero">
            <div>
                <h1>Sensor Admin Dashboard</h1>
                <p>Quan ly sensor, xem logs Elasticsearch va cai dat thoi gian rotate log.</p>
            </div>
            <div class="row">
                <span id="whoami" class="small" style="color:#fff"></span>
                <button class="danger" onclick="logout()">Dang xuat</button>
            </div>
        </div>

        <div class="grid">
            <section class="card full">
                <h2>Doi Tai Khoan Admin</h2>
                <div class="row">
                    <input id="currentPassword" type="password" placeholder="Current password" style="min-width:220px" />
                    <input id="newUsername" placeholder="New username (optional)" style="min-width:220px" />
                    <input id="newPassword" type="password" placeholder="New password (optional)" style="min-width:220px" />
                    <button class="alt" onclick="updateAdminAccount()">Cap nhat</button>
                </div>
                <div id="adminInfo" class="small" style="margin-top:8px">Thong tin admin duoc luu trong PostgreSQL.</div>
            </section>

            <section class="card">
                <h2>Sensors</h2>
                <div class="row">
                    <input id="newSensorName" placeholder="Ten sensor" />
                    <button onclick="createSensor()">Tao sensor</button>
                    <button class="alt" onclick="loadSensors()">Tai lai</button>
                </div>
                <table id="sensorTable">
                    <thead><tr><th>sensor_id</th><th>sensor</th><th>active</th><th>actions</th></tr></thead>
                    <tbody></tbody>
                </table>
            </section>

            <section class="card">
                <h2>Log Rotation (Elasticsearch ILM)</h2>
                <div class="row">
                    <input id="rollover" placeholder="rollover_max_age vd: 1d" />
                    <input id="delete" placeholder="delete_min_age vd: 30d" />
                </div>
                <div class="row" style="margin-top:8px">
                    <button onclick="saveRotation()">Cap nhat</button>
                    <button class="alt" onclick="loadRotation()">Lay cau hinh</button>
                </div>
                <div id="rotationInfo" class="small" style="margin-top:8px"></div>
            </section>

            <section class="card full">
                <h2>Recent Logs</h2>
                <div class="row">
                    <input id="logSize" value="20" placeholder="So luong" />
                    <button onclick="loadLogs()">Tai logs</button>
                </div>
                <pre id="logOutput" class="mono"></pre>
            </section>
        </div>
    </div>

    <script>
        function adminHeaders() {
            return {
                'Content-Type': 'application/json',
                'X-Admin-Username': sessionStorage.getItem('adminUsername') || '',
                'X-Admin-Password': sessionStorage.getItem('adminPassword') || '',
            };
        }

        async function ensureLogin() {
            const res = await fetch('/admin/account', { headers: adminHeaders() });
            if (!res.ok) {
                window.location.href = '/admin/ui/login';
                return false;
            }
            const body = await res.json();
            document.getElementById('adminInfo').textContent = `Admin hien tai: ${body.username}`;
            document.getElementById('whoami').textContent = `Dang nhap: ${body.username}`;
            return true;
        }

        function logout() {
            sessionStorage.removeItem('adminUsername');
            sessionStorage.removeItem('adminPassword');
            window.location.href = '/admin/ui/login';
        }

        async function updateAdminAccount() {
            const current_password = document.getElementById('currentPassword').value;
            const new_username = document.getElementById('newUsername').value.trim();
            const new_password = document.getElementById('newPassword').value;
            const payload = { current_password };
            if (new_username) payload.new_username = new_username;
            if (new_password) payload.new_password = new_password;

            const res = await fetch('/admin/account', {
                method: 'PUT',
                headers: adminHeaders(),
                body: JSON.stringify(payload),
            });
            const body = await res.json();
            if (!res.ok) return alert(body.detail || 'Doi tai khoan/mat khau that bai');

            if (new_username) sessionStorage.setItem('adminUsername', new_username);
            if (new_password) sessionStorage.setItem('adminPassword', new_password);
            alert('Da cap nhat tai khoan admin');
            ensureLogin();
        }

        async function loadSensors() {
            const res = await fetch('/admin/sensors', { headers: adminHeaders() });
            if (!res.ok) return alert('Khong tai duoc sensors');
            const data = await res.json();
            const tbody = document.querySelector('#sensorTable tbody');
            tbody.innerHTML = '';
            data.forEach(s => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="mono">${s.sensor_id}</td>
                    <td><input value="${s.sensor || ''}" id="n-${s.sensor_id}" /></td>
                    <td><input type="checkbox" id="a-${s.sensor_id}" ${s.active ? 'checked' : ''} /></td>
                    <td>
                        <button onclick="updateSensor('${s.sensor_id}')">Luu</button>
                        <button class="alt" onclick="rotateKey('${s.sensor_id}')">Rotate key</button>
                        <button class="danger" onclick="deleteSensor('${s.sensor_id}')">Xoa</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        async function createSensor() {
            const sensor = document.getElementById('newSensorName').value;
            const res = await fetch('/admin/sensors', {
                method: 'POST', headers: adminHeaders(), body: JSON.stringify({ sensor })
            });
            const body = await res.json();
            if (!res.ok) return alert(body.detail || 'Tao sensor that bai');
            alert(`Tao thanh cong\nSensor ID: ${body.sensor_id}\nAPI Key: ${body.api_key}`);
            loadSensors();
        }

        async function updateSensor(sensorId) {
            const sensor = document.getElementById(`n-${sensorId}`).value;
            const active = document.getElementById(`a-${sensorId}`).checked;
            const res = await fetch(`/admin/sensors/${sensorId}`, {
                method: 'PUT', headers: adminHeaders(), body: JSON.stringify({ sensor, active, rotate_api_key: false })
            });
            if (!res.ok) return alert('Cap nhat that bai');
            alert('Da cap nhat sensor');
            loadSensors();
        }

        async function rotateKey(sensorId) {
            const res = await fetch(`/admin/sensors/${sensorId}`, {
                method: 'PUT', headers: adminHeaders(), body: JSON.stringify({ rotate_api_key: true })
            });
            const body = await res.json();
            if (!res.ok) return alert(body.detail || 'Rotate key that bai');
            alert(`API key moi: ${body.api_key}`);
        }

        async function deleteSensor(sensorId) {
            if (!confirm('Xoa sensor nay?')) return;
            const res = await fetch(`/admin/sensors/${sensorId}`, { method: 'DELETE', headers: adminHeaders() });
            if (!res.ok) return alert('Xoa that bai');
            loadSensors();
        }

        async function loadLogs() {
            const size = parseInt(document.getElementById('logSize').value || '20', 10);
            const res = await fetch(`/admin/logs?size=${size}`, { headers: adminHeaders() });
            const body = await res.json();
            if (!res.ok) return alert(body.detail || 'Khong tai duoc logs');
            document.getElementById('logOutput').textContent = JSON.stringify(body, null, 2);
        }

        async function loadRotation() {
            const res = await fetch('/admin/log-rotation', { headers: adminHeaders() });
            const body = await res.json();
            if (!res.ok) return alert(body.detail || 'Khong lay duoc cau hinh rotation');
            document.getElementById('rollover').value = body.rollover_max_age;
            document.getElementById('delete').value = body.delete_min_age;
            document.getElementById('rotationInfo').textContent = `Policy: ${body.policy_name}`;
        }

        async function saveRotation() {
            const rollover_max_age = document.getElementById('rollover').value.trim();
            const delete_min_age = document.getElementById('delete').value.trim();
            const res = await fetch('/admin/log-rotation', {
                method: 'PUT', headers: adminHeaders(), body: JSON.stringify({ rollover_max_age, delete_min_age })
            });
            const body = await res.json();
            if (!res.ok) return alert(body.detail || 'Cap nhat rotation that bai');
            document.getElementById('rotationInfo').textContent = `Da cap nhat: rollover=${body.rollover_max_age}, delete=${body.delete_min_age}`;
            alert('Da cap nhat log rotation');
        }

        (async () => {
            const ok = await ensureLogin();
            if (!ok) return;
            loadSensors();
            loadRotation();
        })();
    </script>
</body>
</html>
"""


@app.get("/health")
def health_check() -> dict[str, Any]:
    return {"status": "ok"}


@app.get("/admin/ui")
def admin_ui_redirect() -> RedirectResponse:
    return RedirectResponse(url="/admin/ui/login")


@app.get("/admin/ui/login", response_class=HTMLResponse)
def admin_ui_login() -> str:
    return LOGIN_HTML


@app.get("/admin/ui/admin", response_class=HTMLResponse)
def admin_ui_admin() -> str:
    return ADMIN_DASHBOARD_HTML


@app.get(
    "/admin/account",
)
def get_admin_account(admin: AdminAccount = Depends(require_admin)) -> Dict[str, str]:
    return {"username": admin.username}


@app.post("/admin/token")
def issue_admin_token(body: AdminTokenRequest, db: Session = Depends(get_db)) -> Dict[str, Any]:
    admin = authenticate_admin_credentials(db, body.username, body.password)
    token = create_admin_token(admin)
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": ADMIN_TOKEN_EXPIRES_SECONDS,
        "username": admin.username,
    }


@app.put(
    "/admin/account",
)
def update_admin_account(
    body: AdminAccountUpdateRequest,
    admin: AdminAccount = Depends(require_admin),
    db: Session = Depends(get_db),
) -> Dict[str, str]:
    if admin.password_hash != hash_secret(body.current_password):
        raise HTTPException(status_code=401, detail="Current password is incorrect")

    target_username = body.new_username or admin.username
    if target_username != admin.username and db.get(AdminAccount, target_username) is not None:
        raise HTTPException(status_code=409, detail="Username already exists")

    target_password_hash = admin.password_hash
    if body.new_password:
        target_password_hash = hash_secret(body.new_password)

    if target_username != admin.username:
        new_admin = AdminAccount(username=target_username, password_hash=target_password_hash)
        db.add(new_admin)
        db.delete(admin)
    else:
        admin.password_hash = target_password_hash
        db.add(admin)

    db.commit()
    return {"message": "Admin account updated", "username": target_username}


class AdminUserCreate(BaseModel):
    username: str
    password: str


class StorageConnectionCreateRequest(BaseModel):
    name: str
    es_url: str
    es_username: Optional[str] = None
    es_password: Optional[str] = None
    is_active: bool = False

    @model_validator(mode="after")
    def validate_connection(self) -> "StorageConnectionCreateRequest":
        if not self.name.strip():
            raise ValueError("name is required")
        if not self.es_url.strip():
            raise ValueError("es_url is required")
        if not self.es_url.startswith("http://") and not self.es_url.startswith("https://"):
            raise ValueError("es_url must start with http:// or https://")
        return self


class StorageConnectionUpdateRequest(BaseModel):
    name: Optional[str] = None
    es_url: Optional[str] = None
    es_username: Optional[str] = None
    es_password: Optional[str] = None
    is_active: Optional[bool] = None

    @model_validator(mode="after")
    def validate_connection(self) -> "StorageConnectionUpdateRequest":
        if self.es_url is not None and self.es_url.strip() and not self.es_url.startswith("http://") and not self.es_url.startswith("https://"):
            raise ValueError("es_url must start with http:// or https://")
        return self


class StorageConnectionResponse(BaseModel):
    id: int
    name: str
    es_url: str
    es_username: Optional[str]
    has_password: bool
    is_active: bool


class AdminUserPasswordUpdate(BaseModel):
    current_password: str
    new_password: str

    @model_validator(mode="after")
    def validate_password(self) -> "AdminUserPasswordUpdate":
        if not self.current_password.strip():
            raise ValueError("current_password is required")
        if not self.new_password.strip():
            raise ValueError("new_password is required")
        return self


def build_es_client_for_connection(connection: StorageConnection) -> Elasticsearch:
    username = (connection.es_username or "").strip()
    password = connection.es_password or ""
    if username and password:
        return Elasticsearch(connection.es_url, basic_auth=(username, password))
    return Elasticsearch(connection.es_url)


def serialize_storage_connection(connection: StorageConnection) -> StorageConnectionResponse:
    return StorageConnectionResponse(
        id=connection.id,
        name=connection.name,
        es_url=connection.es_url,
        es_username=connection.es_username,
        has_password=bool(connection.es_password),
        is_active=connection.is_active,
    )

@app.get(
    "/admin/users",
    response_model=List[Dict[str, str]],
    dependencies=[Depends(require_admin)],
)
def list_admin_users(db: Session = Depends(get_db)):
    stmt = select(AdminAccount.username)
    usernames = db.execute(stmt).scalars().all()
    return [{"username": u} for u in usernames]

@app.post(
    "/admin/users",
    dependencies=[Depends(require_admin)],
)
def create_admin_user(body: AdminUserCreate, db: Session = Depends(get_db)):
    if db.get(AdminAccount, body.username) is not None:
        raise HTTPException(status_code=409, detail="Username already exists")
    new_admin = AdminAccount(
        username=body.username,
        password_hash=hash_secret(body.password),
    )
    db.add(new_admin)
    db.commit()
    return {"username": new_admin.username, "message": "Admin user created"}


@app.put(
    "/admin/users/{username}/password",
    dependencies=[Depends(require_admin)],
)
def update_admin_user_password(
    username: str,
    body: AdminUserPasswordUpdate,
    admin: AdminAccount = Depends(require_admin),
    db: Session = Depends(get_db),
):
    if admin.password_hash != hash_secret(body.current_password):
        raise HTTPException(status_code=401, detail="Current admin password is incorrect")

    target_admin = db.get(AdminAccount, username)
    if target_admin is None:
        raise HTTPException(status_code=404, detail="User not found")

    target_admin.password_hash = hash_secret(body.new_password)
    db.add(target_admin)
    db.commit()
    return {"username": target_admin.username, "message": "Password updated"}


@app.get(
    "/admin/storage/connections",
    response_model=List[StorageConnectionResponse],
    dependencies=[Depends(require_admin)],
)
def list_storage_connections(db: Session = Depends(get_db)) -> List[StorageConnectionResponse]:
    stmt = select(StorageConnection)
    rows = db.execute(stmt).scalars().all()
    return [serialize_storage_connection(row) for row in rows]


@app.post(
    "/admin/storage/connections",
    response_model=StorageConnectionResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_admin)],
)
def create_storage_connection(
    body: StorageConnectionCreateRequest,
    db: Session = Depends(get_db),
) -> StorageConnectionResponse:
    existing = db.execute(select(StorageConnection).where(StorageConnection.name == body.name)).scalar_one_or_none()
    if existing is not None:
        raise HTTPException(status_code=409, detail="Connection name already exists")

    if body.is_active:
        for row in db.execute(select(StorageConnection)).scalars().all():
            row.is_active = False
            db.add(row)

    connection = StorageConnection(
        name=body.name.strip(),
        es_url=body.es_url.strip(),
        es_username=(body.es_username or "").strip() or None,
        es_password=(body.es_password or "").strip() or None,
        is_active=body.is_active,
    )
    db.add(connection)
    db.commit()
    db.refresh(connection)
    return serialize_storage_connection(connection)


@app.put(
    "/admin/storage/connections/{connection_id}",
    response_model=StorageConnectionResponse,
    dependencies=[Depends(require_admin)],
)
def update_storage_connection(
    connection_id: int,
    body: StorageConnectionUpdateRequest,
    db: Session = Depends(get_db),
) -> StorageConnectionResponse:
    connection = db.get(StorageConnection, connection_id)
    if connection is None:
        raise HTTPException(status_code=404, detail="Storage connection not found")

    if body.name is not None:
        new_name = body.name.strip()
        if not new_name:
            raise HTTPException(status_code=400, detail="name is required")
        existing = db.execute(
            select(StorageConnection).where(StorageConnection.name == new_name, StorageConnection.id != connection_id)
        ).scalar_one_or_none()
        if existing is not None:
            raise HTTPException(status_code=409, detail="Connection name already exists")
        connection.name = new_name

    if body.es_url is not None:
        if not body.es_url.strip():
            raise HTTPException(status_code=400, detail="es_url is required")
        connection.es_url = body.es_url.strip()

    if body.es_username is not None:
        connection.es_username = body.es_username.strip() or None

    if body.es_password is not None:
        connection.es_password = body.es_password.strip() or None

    if body.is_active is not None:
        if body.is_active:
            for row in db.execute(select(StorageConnection)).scalars().all():
                row.is_active = False
                db.add(row)
            connection.is_active = True
        else:
            connection.is_active = False

    db.add(connection)
    db.commit()
    db.refresh(connection)
    return serialize_storage_connection(connection)


@app.delete(
    "/admin/storage/connections/{connection_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(require_admin)],
)
def delete_storage_connection(connection_id: int, db: Session = Depends(get_db)) -> None:
    connection = db.get(StorageConnection, connection_id)
    if connection is None:
        raise HTTPException(status_code=404, detail="Storage connection not found")

    db.delete(connection)
    db.commit()


@app.post(
    "/admin/storage/connections/{connection_id}/test",
    dependencies=[Depends(require_admin)],
)
def test_storage_connection(connection_id: int, db: Session = Depends(get_db)) -> Dict[str, Any]:
    connection = db.get(StorageConnection, connection_id)
    if connection is None:
        raise HTTPException(status_code=404, detail="Storage connection not found")

    client = build_es_client_for_connection(connection)
    try:
        ok = client.ping()
        if not ok:
            raise HTTPException(status_code=400, detail="Ping failed")
        info = client.info()
        return {
            "ok": True,
            "cluster_name": info.get("cluster_name"),
            "version": info.get("version", {}).get("number"),
            "tagline": info.get("tagline"),
        }
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(status_code=400, detail=f"Failed to connect: {str(ex)}")
    finally:
        client.close()


@app.get(
    "/admin/a05/config",
    response_model=A05ConfigResponse,
    dependencies=[Depends(require_admin)],
)
def get_a05_config(db: Session = Depends(get_db)) -> A05ConfigResponse:
    row = db.execute(select(A05Connection).limit(1)).scalar_one_or_none()
    if row is None:
        ensure_default_a05_connection(db)
        row = db.execute(select(A05Connection).limit(1)).scalar_one()
    return serialize_a05_config(row)


@app.put(
    "/admin/a05/config",
    response_model=A05ConfigResponse,
    dependencies=[Depends(require_admin)],
)
def update_a05_config(body: A05ConfigUpdateRequest, db: Session = Depends(get_db)) -> A05ConfigResponse:
    row = db.execute(select(A05Connection).limit(1)).scalar_one_or_none()
    if row is None:
        ensure_default_a05_connection(db)
        row = db.execute(select(A05Connection).limit(1)).scalar_one()

    row.enabled = body.enabled
    row.endpoint_url = body.endpoint_url.strip()
    row.vendor_id = body.vendor_id.strip()
    row.unit_id = body.unit_id.strip()
    row.sensor_id = body.sensor_id.strip()
    row.timeout_seconds = body.timeout_seconds
    row.verify_ssl = body.verify_ssl
    if body.api_key is not None and body.api_key.strip():
        row.api_key = body.api_key.strip()

    db.add(row)
    db.commit()
    db.refresh(row)
    return serialize_a05_config(row)


@app.post(
    "/admin/a05/test",
    dependencies=[Depends(require_admin)],
)
def test_a05_config(db: Session = Depends(get_db)) -> Dict[str, Any]:
    row = db.execute(select(A05Connection).limit(1)).scalar_one_or_none()
    if row is None:
        raise HTTPException(status_code=404, detail="A05 config not found")
    if not row.api_key:
        raise HTTPException(status_code=400, detail="A05 api_key is not configured")

    test_event = {
        "timestamp": time.time(),
        "category": 0,
        "action": 0,
        "signature": "A05 test event",
        "severity": 1,
        "direction": 0,
        "dest_ip": "127.0.0.1",
        "dest_port": 0,
        "src_ip": "127.0.0.1",
        "src_port": 0,
        "proto": "TEST",
        "host": "A05_TEST",
        "tags": 0,
        "domain": "a05-test.local",
    }

    try:
        result = forward_event_to_a05(row, test_event)
        if not result["ok"]:
            raise HTTPException(
                status_code=502,
                detail={
                    "message": "A05 returned non-success status",
                    "a05_status_code": result["status_code"],
                    "a05_response_text": result["response_text"],
                    "a05_endpoint": result["endpoint_url"],
                },
            )
        return {"ok": True, **result}
    except requests.exceptions.RequestException as ex:
        raise HTTPException(status_code=400, detail=f"A05 connection failed: {str(ex)}")
    except Exception as ex:
        raise HTTPException(status_code=400, detail=f"A05 configuration error: {str(ex)}")

@app.delete(
    "/admin/users/{username}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(require_admin)],
)
def delete_admin_user(
    username: str,
    admin: AdminAccount = Depends(require_admin),
    db: Session = Depends(get_db),
):
    if admin.username == username:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    
    target_admin = db.get(AdminAccount, username)
    if target_admin is None:
        raise HTTPException(status_code=404, detail="User not found")
        
    stmt = select(AdminAccount)
    total_admins = len(db.execute(stmt).scalars().all())
    if total_admins <= 1:
        raise HTTPException(status_code=400, detail="Cannot delete the last admin account")

    db.delete(target_admin)
    db.commit()


@app.post("/ingest")
def ingest(
    payload: IngestRequest,
    db: Session = Depends(get_db),
    api_key: Optional[str] = Header(default=None, alias="API-Key"),
    sensor_id_header: Optional[str] = Header(default=None, alias="sensor_id"),
    sensor_id_alt_header: Optional[str] = Header(default=None, alias="Sensor-Id"),
) -> dict[str, Any]:
    global es_client

    if not api_key:
        raise HTTPException(status_code=401, detail="Missing API-Key header")

    sensor_id = (sensor_id_header or sensor_id_alt_header or "").strip()
    if not sensor_id:
        raise HTTPException(status_code=401, detail="Missing sensor_id header")

    verify_sensor_credentials(db, sensor_id, api_key)

    if es_client is None:
        raise HTTPException(status_code=500, detail="Elasticsearch client is not initialized")

    actions = []
    for item in payload.data:
        doc = item.model_dump()
        doc["sensor_id"] = sensor_id

        actions.append(
            {
                "_index": ES_WRITE_ALIAS,
                "_source": doc,
            }
        )

    try:
        helpers.bulk(es_client, actions)
    except Exception as ex:
        raise HTTPException(status_code=500, detail=f"Failed to write to Elasticsearch: {str(ex)}")

    a05_forwarded = 0
    a05_errors: List[str] = []
    a05_results: List[Dict[str, Any]] = []
    a05_row = db.execute(select(A05Connection).limit(1)).scalar_one_or_none()
    if a05_row is not None and a05_row.enabled and a05_row.api_key:
        for item in payload.data:
            try:
                result = forward_event_to_a05(a05_row, item.model_dump())
                if result["ok"]:
                    a05_forwarded += 1
                else:
                    logger.warning(
                        "A05 PUT non-success endpoint=%s status=%s response=%s",
                        result["endpoint_url"],
                        result["status_code"],
                        result["response_text"][:1000],
                    )
                    a05_errors.append(
                        f"A05 returned status {result['status_code']}: {result['response_text'][:300]}"
                    )
                if len(a05_results) < 3:
                    a05_results.append(
                        {
                            "endpoint_url": result["endpoint_url"],
                            "status_code": result["status_code"],
                            "ok": result["ok"],
                            "response_text": result["response_text"][:500],
                            "request_payload": result["request_payload"],
                        }
                    )
            except requests.exceptions.RequestException as ex:
                logger.warning("A05 forward failed endpoint=%s error=%s", a05_row.endpoint_url, str(ex))
                a05_errors.append(str(ex))
            except Exception as ex:
                logger.warning("A05 config/encoding error endpoint=%s error=%s", a05_row.endpoint_url, str(ex))
                a05_errors.append(str(ex))

    logger.info(
        "A05 ingest summary ingested=%s forwarded=%s errors=%s",
        len(actions),
        a05_forwarded,
        len(a05_errors),
    )

    return {
        "message": "Ingested successfully",
        "ingested": len(actions),
        "a05_forwarded": a05_forwarded,
        "a05_errors": a05_errors[:3],
        "a05_results": a05_results,
    }


@app.get(
    "/admin/logs",
    dependencies=[Depends(require_admin)],
)
def list_logs(size: int = 20) -> dict[str, Any]:
    global es_client
    if es_client is None:
        raise HTTPException(status_code=500, detail="Elasticsearch client is not initialized")

    safe_size = max(1, min(size, 500))
    query = {
        "size": safe_size,
        "sort": [{"timestamp": {"order": "desc", "unmapped_type": "double"}}],
        "query": {"match_all": {}},
    }
    try:
        result = es_client.search(index=f"{ES_INDEX}-*", body=query)
    except Exception as ex:
        raise HTTPException(status_code=500, detail=f"Failed to query logs: {str(ex)}")

    hits = result.get("hits", {}).get("hits", [])
    logs = []
    for h in hits:
        logs.append(
            {
                "index": h.get("_index"),
                "id": h.get("_id"),
                "score": h.get("_score"),
                "source": h.get("_source", {}),
            }
        )
    return {"count": len(logs), "logs": logs}


@app.get(
    "/admin/stats/monthly",
    dependencies=[Depends(require_admin)],
)
def get_monthly_stats(days: int = 30) -> Dict[str, Any]:
    global es_client
    if es_client is None:
        raise HTTPException(status_code=500, detail="Elasticsearch client is not initialized")

    safe_days = max(7, min(days, 90))
    now_ts = int(time.time())
    from_ts = now_ts - (safe_days * 86400)
    now_ts_ms = now_ts * 1000
    from_ts_ms = from_ts * 1000

    def build_search_body(sensor_field: str) -> Dict[str, Any]:
        return {
            "track_total_hits": True,
            "size": 0,
            "query": {
                "bool": {
                    "should": [
                        {
                            "range": {
                                "timestamp": {
                                    "gte": from_ts,
                                    "lte": now_ts,
                                }
                            }
                        },
                        {
                            "range": {
                                "timestamp": {
                                    "gte": from_ts_ms,
                                    "lte": now_ts_ms,
                                }
                            }
                        },
                    ],
                    "minimum_should_match": 1,
                }
            },
            "aggs": {
                "events_per_sensor": {
                    "terms": {
                        "field": sensor_field,
                        "size": 200,
                        "order": {"_count": "desc"},
                    },
                    "aggs": {
                        "latest_timestamp": {
                            "max": {
                                "script": {
                                    "source": "double ts = doc['timestamp'].value; return ts > 1000000000000L ? ts / 1000.0 : ts;"
                                }
                            }
                        }
                    },
                },
                "events_per_day": {
                    "histogram": {
                        "script": {
                            "source": "double ts = doc['timestamp'].value; return ts > 1000000000000L ? ts / 1000.0 : ts;"
                        },
                        "interval": 86400,
                        "min_doc_count": 0,
                        "extended_bounds": {
                            "min": from_ts,
                            "max": now_ts,
                        },
                    },
                    "aggs": {
                        "by_sensor": {
                            "terms": {
                                "field": sensor_field,
                                "size": 50,
                            }
                        }
                    },
                },
            },
        }

    search_body = build_search_body("sensor_id.keyword")
    try:
        result = es_client.search(index=f"{ES_INDEX}-*", body=search_body)
    except Exception:
        search_body = build_search_body("sensor_id")
        try:
            result = es_client.search(index=f"{ES_INDEX}-*", body=search_body)
        except Exception as ex:
            raise HTTPException(status_code=500, detail=f"Failed to query monthly stats: {str(ex)}")

    total_events = result.get("hits", {}).get("total", {}).get("value", 0)

    sensor_buckets = result.get("aggregations", {}).get("events_per_sensor", {}).get("buckets", [])
    per_sensor = [
        {
            "sensor_id": bucket.get("key", "unknown"),
            "event_count": bucket.get("doc_count", 0),
            "last_log_timestamp": int(bucket.get("latest_timestamp", {}).get("value", 0) or 0),
            "last_log_time": (
                time.strftime(
                    "%Y-%m-%d %H:%M:%S UTC+7",
                    time.gmtime(int(bucket.get("latest_timestamp", {}).get("value", 0)) + 7 * 3600),
                )
                if bucket.get("latest_timestamp", {}).get("value")
                else None
            ),
        }
        for bucket in sensor_buckets
    ]

    day_buckets = result.get("aggregations", {}).get("events_per_day", {}).get("buckets", [])
    daily_series: List[Dict[str, Any]] = []
    for bucket in day_buckets:
        sensor_counts: Dict[str, int] = {}
        for sensor_bucket in bucket.get("by_sensor", {}).get("buckets", []):
            sensor_counts[sensor_bucket.get("key", "unknown")] = sensor_bucket.get("doc_count", 0)

        bucket_ts = int(bucket.get("key", 0))
        daily_series.append(
            {
                "date": time.strftime("%Y-%m-%d", time.gmtime(bucket_ts)),
                "timestamp": bucket_ts,
                "total": bucket.get("doc_count", 0),
                "sensor_counts": sensor_counts,
            }
        )

    return {
        "days": safe_days,
        "total_events": total_events,
        "per_sensor": per_sensor,
        "daily_series": daily_series,
    }


@app.get(
    "/admin/log-rotation",
    dependencies=[Depends(require_admin)],
)
def get_log_rotation() -> Dict[str, str]:
    global es_client
    if es_client is None:
        raise HTTPException(status_code=500, detail="Elasticsearch client is not initialized")

    try:
        policy = es_client.ilm.get_lifecycle(name=ES_ILM_POLICY_NAME)
        policy_def = policy[ES_ILM_POLICY_NAME]["policy"]
        rollover = policy_def["phases"]["hot"]["actions"]["rollover"]["max_age"]
        delete = policy_def["phases"]["delete"]["min_age"]
    except Exception as ex:
        raise HTTPException(status_code=500, detail=f"Failed to read rotation policy: {str(ex)}")

    return {
        "policy_name": ES_ILM_POLICY_NAME,
        "rollover_max_age": rollover,
        "delete_min_age": delete,
    }


@app.put(
    "/admin/log-rotation",
    dependencies=[Depends(require_admin)],
)
def update_log_rotation(body: LogRotationConfig) -> Dict[str, str]:
    global es_client
    if es_client is None:
        raise HTTPException(status_code=500, detail="Elasticsearch client is not initialized")

    try:
        ensure_index_management(es_client, body.rollover_max_age, body.delete_min_age)
    except Exception as ex:
        raise HTTPException(status_code=500, detail=f"Failed to update rotation policy: {str(ex)}")

    return {
        "message": "Updated log rotation policy",
        "policy_name": ES_ILM_POLICY_NAME,
        "rollover_max_age": body.rollover_max_age,
        "delete_min_age": body.delete_min_age,
    }


@app.get(
    "/admin/sensors",
    response_model=List[SensorPublicResponse],
    dependencies=[Depends(require_admin)],
)
def list_sensors(db: Session = Depends(get_db)) -> List[SensorPublicResponse]:
    stmt = select(Sensor)
    sensors = db.execute(stmt).scalars().all()
    return [
        SensorPublicResponse(sensor_id=s.sensor_id, sensor=s.sensor, active=s.active)
        for s in sensors
    ]


@app.post(
    "/admin/sensors",
    response_model=SensorCreateResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_admin)],
)
def create_sensor(
    body: SensorCreateRequest,
    db: Session = Depends(get_db),
) -> SensorCreateResponse:
    while True:
        sensor_id = generate_sensor_id()
        if db.get(Sensor, sensor_id) is None:
            break

    raw_api_key = generate_api_key()
    sensor = Sensor(
        sensor_id=sensor_id,
        sensor=body.sensor,
        api_key_hash=hash_api_key(raw_api_key),
        active=True,
    )
    db.add(sensor)
    db.commit()

    return SensorCreateResponse(
        sensor_id=sensor.sensor_id,
        sensor=sensor.sensor,
        active=sensor.active,
        api_key=raw_api_key,
    )


@app.put(
    "/admin/sensors/{sensor_id}",
    response_model=SensorCreateResponse,
    dependencies=[Depends(require_admin)],
)
def update_sensor(
    sensor_id: str,
    body: SensorUpdateRequest,
    db: Session = Depends(get_db),
) -> SensorCreateResponse:
    sensor = db.get(Sensor, sensor_id)
    if sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")

    if body.sensor is not None:
        sensor.sensor = body.sensor
    if body.active is not None:
        sensor.active = body.active

    new_api_key = ""
    if body.rotate_api_key:
        new_api_key = generate_api_key()
        sensor.api_key_hash = hash_api_key(new_api_key)

    db.commit()
    db.refresh(sensor)

    return SensorCreateResponse(
        sensor_id=sensor.sensor_id,
        sensor=sensor.sensor,
        active=sensor.active,
        api_key=new_api_key,
    )


@app.delete(
    "/admin/sensors/{sensor_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(require_admin)],
)
def delete_sensor(sensor_id: str, db: Session = Depends(get_db)) -> None:
    sensor = db.get(Sensor, sensor_id)
    if sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")

    db.delete(sensor)
    db.commit()
