# Sensor Ingest API (FastAPI + Elasticsearch)

API nhan du lieu sensor, xac thuc bang `sensor_id` + `API-Key`, va luu vao Elasticsearch.
Thong tin sensor (`sensor`, `sensor_id`, `api_key`) duoc quan ly rieng trong PostgreSQL.

## 1) Cai dat

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 2) Cau hinh

Sao chep `.env.example` thanh `.env` va cap nhat gia tri:

- `DEFAULT_ADMIN_USERNAME`, `DEFAULT_ADMIN_PASSWORD`: tai khoan admin mac dinh, duoc seed vao PostgreSQL lan dau khoi dong
- `DATABASE_URL`: PostgreSQL cho metadata sensor
- `ES_URL`, `ES_USERNAME`, `ES_PASSWORD`, `ES_INDEX`
- `ES_ROLLOVER_MAX_AGE`: thoi gian tao index moi (vd `1d`)
- `ES_DELETE_MIN_AGE`: thoi gian giu log truoc khi xoa (vd `30d`)

## 3) Chay API

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## 3.1) Chay bang Docker Compose

Luu y tren Windows: can mo Docker Desktop va bao dam Docker Engine dang running truoc khi chay compose.

```bash
docker compose up -d --build
```

Stack se chay:

- API: `http://localhost:8000`
- Elasticsearch: `http://localhost:9201`
- PostgreSQL: `localhost:5432` (db=`sensor_db`, user=`sensor_admin`)
- Next.js Login UI: `http://localhost:3001/login`
- Next.js Admin Dashboard: `http://localhost:3001/admin`

Tat stack:

```bash
docker compose down
```

Neu muon xoa ca data volume:

```bash
docker compose down -v
```

## 4) API ingest

`POST /ingest`

Body (nhu ban cung cap):

```json
{
  "sensor_id": "ad2bd838f1977b46636b81c9",
  "API-Key": "***************",
  "data": [
    {
      "timestamp": 1565835901.0123236,
      "category": 8,
      "action": 6,
      "signature": "APT",
      "severity": 3,
      "direction": 0,
      "dest_ip": "81.182.250.130",
      "dest_port": 1435,
      "src_ip": "192.168.71.238",
      "src_port": 57879,
      "proto": "SMTP",
      "host": "CYQPTL",
      "tags": 1,
      "domain": "orlando.com",
      "geoip": {
        "lat": -68.195,
        "lon": -121.5345,
        "ip": "81.182.250.130",
        "city_name": "Kreitzer",
        "countryname": "Darlene",
        "country_code": "FR",
        "timezone": "Europe/Paris",
        "region_name": "Nancy Hunt"
      }
    }
  ]
}
```

Rule validate payload:

- `domain` la tuy chon.
- Neu `tags = 1` thi `geoip` bat buoc phai co day du cac truong: `lat`, `lon`, `ip`, `city_name`, `countryname`, `country_code`, `timezone`, `region_name`.
- Payload gui len phai la JSON hop le (khong duoc co comment `// ...` trong body JSON).

## 5) API admin quan ly sensor

Tat ca endpoint admin can header:

- `X-Admin-Username: <admin_username>`
- `X-Admin-Password: <admin_password>`

Tai khoan admin mac dinh duoc lay tu `.env` va luu trong PostgreSQL. Sau do co the doi username/password bang API.

### Xem admin hien tai

`GET /admin/account`

### Doi username/password admin

`PUT /admin/account`

Body vi du:

```json
{
  "current_password": "change-me",
  "new_username": "soc-admin",
  "new_password": "new-secret-123"
}
```

### Tao sensor moi

`POST /admin/sensors`

Body:

```json
{
  "sensor": "Sensor Site A"
}
```

Tra ve:

- `sensor_id` (random)
- `api_key` (random)
- thong tin sensor

### Danh sach sensor

`GET /admin/sensors`

### Sua sensor / rotate API key

`PUT /admin/sensors/{sensor_id}`

Body vi du:

```json
{
  "sensor": "Sensor Site A - updated",
  "active": true,
  "rotate_api_key": true
}
```

Neu `rotate_api_key = true`, response tra ve `api_key` moi.

### Xoa sensor

`DELETE /admin/sensors/{sensor_id}`

### Xem logs

`GET /admin/logs?size=20`

### Lay cau hinh log rotation

`GET /admin/log-rotation`

### Cap nhat thoi gian log rotation

`PUT /admin/log-rotation`

Body vi du:

```json
{
  "rollover_max_age": "1d",
  "delete_min_age": "30d"
}
```

## 6) Kiem tra nhanh

- Health check: `GET /health`
- Docs swagger: `http://localhost:8000/docs`
- Next.js UI: `http://localhost:3001`

Vi du tao sensor moi (admin):

```bash
curl -X POST "http://localhost:8000/admin/sensors" \
  -H "Content-Type: application/json" \
  -H "X-Admin-Username: admin" \
  -H "X-Admin-Password: change-me" \
  -d "{\"sensor\":\"Sensor Site A\"}"
```

Lay `sensor_id` + `api_key` tu response de goi `/ingest`.
